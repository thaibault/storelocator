import { Lock, Mapping, PlainObject } from 'clientnode';
import { MarkerClusterer } from '@googlemaps/markerclusterer';
import Web from 'web-component-wrapper/Web';
import { WebComponentAPI } from 'web-component-wrapper/type';
import { Configuration, Icon, InfoWindow, Item, MapImpl, MapMarker, MapMarkerOptions, MapPlaceResult, Maps, SearchConfiguration, Store as BaseStore } from './type';
/**
 * A store locator component to represent searchable items grouped on an
 * interactive map.
 * @property applicationInterfaceLoad - Holds the current promise to retrieve a
 * new maps application interface.
 * @property defaultConfiguration - Holds default extendable
 * configuration object.
 * @property defaultSearchConfiguration - Sets default search box options.
 * @property maps - Holds the currently used maps scope.
 * @property initialized - Indicates whether map has been initialized yet.
 * Avoids re-initializing due to property updates (would be too expensive).
 * @property loaded - Indicates whether map has been finished to initialize.
 * @property configuration - Holds given configuration object.
 * @property resolvedConfiguration - Holds resolved configuration object.
 * @property urlConfiguration - URL given configurations object.
 * @property filter - Filter function to dynamically sort out some stores.
 * @property items - Holds all recognized stores to represent as marker.
 * @property searchResultsStyleProperties - Dynamically computed CSS properties
 * to append to search result list (derived from search input field).
 * @property seenLocations - Saves all seen locations to recognize duplicates.
 * @property highlightedItem - Holds currently highlighted item.
 * @property openWindow - Holds currently opened window instance.
 * @property searchBoxInitialized - Indicates whether search results have been
 * initialized yet.
 * @property searchResultRange - Public editable property to set current search
 * result range. This is useful for pagination implementations in template
 * level.
 * @property searchResults - Saves last found search results.
 * @property searchSegments - Saves last searched segments.
 * @property searchText - Saves last searched string.
 * @property searchWords - Saves last searched words.
 * @property searchResultsDirty - Indicates whether current search results
 * aren't valid anymore.
 * @property default - Sets default value if not alternate value set yet.
 * @property dirty - Indicates whether this component has been modified input.
 * @property disabled - Indicates whether this component is in editable.
 * @property invalid - Indicates whether this component is in invalid state.
 * @property pristine - Indicates whether this component hasn't been modified
 * yet.
 * @property required - Indicates whether this is invalid as long there is no
 * item selected yet.
 * @property valid - Indicates whether this component is in valid state.
 * @property value - Currently selected item (for using as form component).
 * @property map - Holds the currently used map instance.
 * @property markerClusterer - Holds the currently used marker cluster
 * instance.
 * @property resetMarkerCluster - API-method to reset marker cluster.
 * @property lock - Holds instance specific locks.
 */
export declare class StoreLocator<TElement extends Element = HTMLElement, ExternalProperties extends Mapping<unknown> = Mapping<unknown>, InternalProperties extends Mapping<unknown> = Mapping<unknown>, Store extends BaseStore = BaseStore> extends Web<TElement, ExternalProperties, InternalProperties> {
    static applicationInterfaceLoad: Promise<void>;
    static cloneSlots: boolean;
    static content: string;
    static defaultConfiguration: Configuration;
    static defaultSearchConfiguration: SearchConfiguration;
    static maps: Maps;
    static renderSlots: boolean;
    static renderUnsafe: boolean;
    static _name: string;
    initialized: boolean;
    loaded: boolean;
    configuration: Partial<Configuration<Store>> | undefined;
    resolvedConfiguration: Configuration<Store>;
    urlConfiguration: null | PlainObject;
    filter: (_store: Store) => boolean;
    items: Array<Item>;
    searchResultsStyleProperties: Mapping<number | string>;
    seenLocations: Array<string>;
    transformStore: (store: Store) => Store;
    highlightedItem: Item | null;
    openWindow: Partial<InfoWindow> | null;
    searchBoxInitialized: boolean;
    searchResultRange: Array<number> | null;
    searchResults: Array<Item>;
    searchSegments: Array<string>;
    searchText: null | string;
    searchWords: Array<string>;
    searchResultsDirty: boolean;
    name: string;
    default: Item | null;
    dirty: boolean;
    disabled: boolean;
    invalid: boolean;
    pristine: boolean;
    required: boolean;
    valid: boolean;
    value: Item | null;
    map: MapImpl;
    markerClusterer: MarkerClusterer | null;
    resetMarkerCluster: null | (() => void);
    readonly self: typeof StoreLocator;
    readonly lock: Lock<string | undefined>;
    /**
     * Defines dynamic getter and setter interface and resolves configuration
     * object. Initializes the map implementation.
     */
    constructor();
    /**
     * Converts given declarative icon configuration to marker needed format.
     * @param options - Icon configuration.
     * @returns Icon configuration.
     */
    transformIconConfiguration(options: Icon): Icon;
    /**
     * Parses given configuration object and (re-)renders map.
     * @param name - Attribute name which was updates.
     * @param oldValue - Old attribute value.
     * @param newValue - New updated value.
     */
    attributeChangedCallback(name: string, oldValue: string, newValue: string): void;
    /**
     * De-registers all needed event listener.
     */
    disconnectedCallback(): void;
    /**
     * Generic internal property setter. Forwards field writes into internal.
     * @param name - Property name to write.
     * @param value - New value to write.
     */
    setInternalPropertyValue(name: string, value: unknown): void;
    /**
     * Triggered when content projected and nested dom nodes are ready to be
     * traversed / injected.
     * @param reason - Description why rendering is necessary.
     * @returns A promise resolving when rendering has finished.
     */
    render(reason?: string): Promise<void>;
    onMapCenterChanged: () => void;
    onInputClick: () => void;
    onInputFocus: () => void;
    onInputKeyDown: (event: KeyboardEvent) => void;
    onKeyDown: (event: KeyboardEvent) => void;
    /**
     * Merges configuration sources into final object.
     */
    resolveConfiguration(): void;
    /**
     * Extends current configuration object by given url parameter.
     * @param name - URL parameter name to interpret.
     */
    extendConfigurationByGivenURLParameter(name?: string): void;
    /**
     * Loads google map resources if not loaded yet (or loading triggered).
     * Initializes map instances.
     * @returns Promise resolving when everything is loaded and initialized.
     */
    loadMapEnvironmentIfNotAvailableAndInitializeMap(): Promise<void>;
    /**
     * Determines useful location cluster, info windows and marker.
     * @returns Promise resolving to the current instance.
     */
    bootstrap: () => Promise<void>;
    /**
     * Adds given store as marker to the map.
     * @param store - Store to add as marker.
     * @returns The currently marked store.
     */
    transformMarker(store: Store): Store;
    /**
     * Initializes given value. Maps to internally determined item and opens
     * corresponding marker. Normalizes from id, data item or item to internal
     * item representation.
     * @param value - Value to initialize.
     * @returns Determined value.
     */
    mapValue(value?: Item | null | number | Store | string): Item | null;
    /**
     * Initializes cluster, info windows and marker.
     * @returns Promise resolving to the current instance.
     */
    initializeMap(): Promise<void>;
    /**
     * Position search results right below the search input field.
     */
    initializeSearchResultsBox(): void;
    /**
     * Initializes a data source based search box to open and focus them
     * matching marker.
     */
    initializeDataSourceSearch(): void;
    /**
     * Update input state.
     */
    updateValueState(): void;
    /**
     * Triggers on each search request.
     * @returns Debounced function.
     */
    get updateSearchResultsHandler(): EventListener;
    /**
     * Sorts and filters search results given by google's application
     * interface.
     * @param places - List of place objects.
     */
    handleGenericSearchResults(places: Array<MapPlaceResult>): void;
    /**
     * Performs a search on locally given store data.
     * @param results - A list if generic search results.
     */
    performLocalSearch(results?: Array<Item>): void;
    /**
     * Opens current search results.
     * @param event - Object with metadata for current event which has
     * triggered to show search results.
     */
    openSearchResults(event?: Event): void;
    /**
     * Closes current search results.
     * @param event - Object with metadata for current event which has
     * triggered to close search results.
     */
    closeSearchResults(event?: Event): void;
    /**
     * Initializes googles generic search box and tries to match to open and
     * focus them.
     */
    initializeGenericSearch(): void;
    /**
     * Closes current window if opened.
     */
    closeCurrentWindow(): void;
    /**
     * Ensures that every given place have a location property.
     * @param places - Places to check for.
     * @returns A promise which will be resolved if all places are ensured.
     */
    ensurePlaceLocations(places: Array<MapPlaceResult>): Promise<Array<MapPlaceResult>>;
    /**
     * Determines the best search result from given list of candidates.
     * The currently nearest result to current viewport will be preferred.
     * @param candidates - List of search results to determine best from.
     * @returns The determined best result.
     */
    determineBestSearchResult(candidates: Array<MapPlaceResult>): MapPlaceResult | null;
    /**
     * Is triggered if the complete map ist loaded.
     * @returns Promise resolving when start up animation has been completed.
     */
    onLoaded(): Promise<void>;
    /**
     * Registers given store to the googlemaps canvas.
     * @param store - Store object to create a marker for.
     * @returns The created marker.
     */
    createMarker(store?: Store): MapMarker;
    /**
     * Create marker configuration from given item.
     * @param item - Marker to derive a configuration from.
     * @returns Configuration object.
     */
    createMarkerConfiguration(item: Item): MapMarkerOptions;
    /**
     * Adds needed event listener to given item marker.
     * @param item - Marker to attach event listener to.
     */
    attachMarkerEventListener(item: Item): void;
    /**
     * Opens given item's marker info window and closes potentially opened
     * windows.
     * @param item - Item's marker to open.
     * @param event - Event which has triggered the marker opening call.
     */
    openMarker(item: Item, event?: Event): void;
    /**
     * Focuses given place on map.
     * @param place - Place to open.
     * @param event - Event object which has triggered requested place opening.
     */
    focusPlace(place: Item, event?: Event): void;
    /**
     * Opens given item's marker info window and closes a potential opened
     * windows.
     * @param item - Marker to Highlight.
     * @param event - Event object for corresponding event that has the
     * highlighting requested.
     * @param type - Type of highlighting.
     */
    highlightMarker(item: Item, event?: Event, type?: string): void;
}
export declare const api: WebComponentAPI<typeof StoreLocator>;
export default api;

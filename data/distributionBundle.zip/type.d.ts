/// <reference types="google.maps" />
import PropertyTypes from 'clientnode/property-types';
import { Mapping, ObjectMaskConfiguration, ProcedureFunction, ValueOf } from 'clientnode/type';
import { MarkerClustererOptions } from '@googlemaps/markerclustererplus';
export declare type MapAnimation = typeof google.maps.Animation;
export declare type MapArea = google.maps.LatLngBounds;
export declare type MapEventListener = google.maps.MapsEventListener;
export declare type MapGeocoder = google.maps.Geocoder;
export declare type MapGeocoderResult = google.maps.GeocoderResult;
export declare type MapGeocoderStatus = google.maps.GeocoderStatus;
export declare type MapIcon = google.maps.Icon;
export declare type MapImpl = google.maps.Map;
export declare type MapInfoWindow = google.maps.InfoWindow;
export declare type MapMarker = google.maps.Marker;
export declare type MapMarkerClustererOptions = MarkerClustererOptions;
export declare type MapMarkerOptions = google.maps.MarkerOptions;
export declare type MapOptions = google.maps.MapOptions;
export declare type MapPosition = google.maps.LatLng;
export declare type MapPlaceResult = google.maps.places.PlaceResult;
export declare type MapPlacesService = google.maps.places.PlacesService;
export declare type MapSearchBox = google.maps.places.SearchBox;
export declare type MapSearchBoxOptions = google.maps.places.SearchBoxOptions;
export declare type MapSize = google.maps.Size;
export declare type Maps = {
    Animation: typeof google.maps.Animation;
    ControlPosition: typeof google.maps.ControlPosition;
    event: {
        addListener: (_instance: InfoWindow | MapImpl | MapInfoWindow | MapMarker | MapSearchBox, _eventName: string, _handler: (event: Event) => void) => MapEventListener;
        addListenerOnce: (_instance: InfoWindow | MapImpl | MapInfoWindow | MapMarker | MapSearchBox, _eventName: string, _handler: (event: Event) => void) => MapEventListener;
    };
    Geocoder: typeof google.maps.Geocoder;
    GeocoderStatus: typeof google.maps.GeocoderStatus;
    geometry: {
        spherical: {
            computeDistanceBetween: (_from: MapPosition, _to: MapPosition, _radius?: number) => number;
        };
    };
    InfoWindow: typeof google.maps.InfoWindow;
    LatLng: typeof google.maps.LatLng;
    LatLngBounds: typeof google.maps.LatLngBounds;
    Map: typeof google.maps.Map;
    Marker: typeof google.maps.Marker;
    mockup?: boolean;
    places: {
        PlacesService: typeof google.maps.places.PlacesService;
        SearchBox: typeof google.maps.places.SearchBox;
    };
    Size: typeof google.maps.Size;
};
export declare type MapTextSearchRequest = google.maps.places.TextSearchRequest;
export declare type PropertyTypes = {
    baseConfiguration: ValueOf<typeof PropertyTypes>;
    configuration: ValueOf<typeof PropertyTypes>;
    dynamicConfiguration: ValueOf<typeof PropertyTypes>;
};
export declare type Store = Mapping<unknown> & {
    address?: string;
    city?: string;
    id?: number | string;
    latitude?: number;
    longitude?: number;
    markerIconFileName?: string;
    street?: string;
    streetAndStreetnumber?: string;
    streetnumber?: string;
    title?: string;
    zipCode?: string;
    zipCodeAndCity?: string;
};
export declare type Square = {
    height: number;
    unit: string;
    width: number;
};
export declare type Icon = {
    scaledSize?: MapSize | Square;
    size?: MapSize | Square;
    url: string;
};
export declare type InfoWindow = MapInfoWindow & {
    isOpen: boolean;
};
export declare type Item<StoreType extends Store = Store> = {
    close?: () => void;
    data: null | StoreType;
    foundWords: Array<string>;
    highlight: (_event?: Event, _type?: string) => void;
    icon?: Icon;
    infoWindow?: InfoWindow;
    isHighlighted: boolean;
    marker?: MapMarker;
    open: (_event?: Event) => void;
    position: MapPosition | null;
    refreshSize?: ProcedureFunction;
    title?: string;
};
export declare type Position = {
    latitude: number;
    longitude: number;
};
export declare type SearchConfiguration = {
    generic: {
        filter: (_place: MapPlaceResult) => boolean;
        maximalDistanceInMeter: number;
        minimumNumberOfSymbols: number;
        number: Array<number>;
        prefer: boolean;
        retrieveOptions: MapTextSearchRequest;
        searchDebounceTimeInMilliseconds: number;
    };
    maximumNumberOfResults: number;
    normalizer: (_value: string) => string;
    properties: Array<string>;
    resultAggregation: 'cut' | 'union';
    stylePropertiesToDeriveFromInputField: Array<string>;
};
export declare type AppearanceConfiguration = {
    hide: Mapping<number | string>;
    showAnimation: [Mapping<number | string>, Mapping<number | string>];
};
export declare type Configuration<StoreItem = Store> = {
    additionalStoreProperties: object;
    defaultMarkerIconFileName?: null | string;
    filter: null | string | ((_store: StoreItem) => boolean);
    stores: Array<StoreItem> | string | {
        generateProperties: (_store: object) => object;
        northEast: Position;
        number: number;
        southWest: Position;
    };
    transform: null | string | ((_store: StoreItem) => StoreItem);
    applicationInterface: {
        callbackName?: null | string;
        key?: null | string;
        url: string;
    };
    debug: boolean;
    distanceToMoveByDuplicatedEntries: number;
    fallbackLocation: Position;
    ip: string;
    ipToLocationApplicationInterface: {
        bounds: {
            northEast: Position;
            southWest: Position;
        };
        key?: null | string;
        protocol: string;
        timeoutInMilliseconds: number;
        url: string;
    };
    startLocation?: null | Position;
    iconPath: string;
    infoWindow: {
        additionalMoveToBottomInPixel: number;
    };
    input: AppearanceConfiguration;
    root: AppearanceConfiguration;
    loadingHideAnimation: [Mapping<number | string>, Mapping<number | string>];
    showInputAfterLoadedDelayInMilliseconds: number;
    limit: {
        northEast: Position;
        southWest: Position;
    };
    map: MapOptions;
    marker: {
        cluster?: MapMarkerClustererOptions | null;
        icon: {
            scaledSize: Square;
            size: Square;
        };
    };
    name: string;
    search: number | SearchConfiguration;
    successfulSearchZoomLevel: number;
    securityResponsePrefix: string;
    urlModelMask: ObjectMaskConfiguration;
};
